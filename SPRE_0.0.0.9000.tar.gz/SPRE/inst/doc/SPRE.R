## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(SPRE)

## ------------------------------------------------------------------------
data("HEAT_stat")

## ----fig.width=7,fig.height=7--------------------------------------------
modelfit<-SPRE(predictor=HEAT_stat$Session,response=HEAT_stat$FData)

## ----fig.width=7,fig.height=7--------------------------------------------
plot_residuals(modelfit)

## ----fig.width=7,fig.height=7--------------------------------------------
stability(modelfit)

## ----fig.width=7,fig.height=7--------------------------------------------
plot_weibull(modelfit)

